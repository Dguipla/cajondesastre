#!/bin/bash

export NIS="yes"
export HADOOP_VERSION=2.7.7