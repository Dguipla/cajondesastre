echo "Removing hdfs, mapred and yarm accounts..."
	userdel -f  hdfs
	userdel -f  mapred
	userdel -f  yarn
	echo "Removing hadoop system group..."
	groupdel hadoop
   	make group -C /var/yp
	make -C /var/yp
	pdsh -w ^all_hosts "rm -r /user/yarn /user/hdfs /user/mapred"