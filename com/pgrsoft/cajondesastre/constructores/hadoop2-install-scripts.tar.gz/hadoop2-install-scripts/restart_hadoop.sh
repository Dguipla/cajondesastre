restart_hadoop()
{
	echo "Restarting Hadoop 2..."
	pdsh -w ^dn_hosts "service hadoop-datanode stop"
	pdsh -w ^snn_host "service hadoop-secondarynamenode stop"
	pdsh -w ^nn_host "service hadoop-namenode stop"
	pdsh -w ^mr_history_host "service hadoop-historyserver stop"
	pdsh -w ^yarn_proxy_host "service hadoop-proxyserver stop"
	pdsh -w ^nm_hosts "service hadoop-nodemanager stop"
	pdsh -w ^rm_host "service hadoop-resourcemanager stop"


	pdsh -w ^nn_host "service hadoop-namenode start"
	pdsh -w ^snn_host "service hadoop-secondarynamenode start"
	pdsh -w ^dn_hosts "service hadoop-datanode start"
	pdsh -w ^rm_host "service hadoop-resourcemanager start"
	pdsh -w ^nm_hosts "service hadoop-nodemanager start"
	pdsh -w ^yarn_proxy_host "service hadoop-proxyserver start"
	pdsh -w ^mr_history_host "service hadoop-historyserver start"
}

stop_hadoop()
{
	echo "Stopping Hadoop 2..."
	pdsh -w ^dn_hosts "service hadoop-datanode stop"
	pdsh -w ^snn_host "service hadoop-secondarynamenode stop"
	pdsh -w ^nn_host "service hadoop-namenode stop"
	pdsh -w ^mr_history_host "service hadoop-historyserver stop"
	pdsh -w ^yarn_proxy_host "service hadoop-proxyserver stop"
	pdsh -w ^nm_hosts "service hadoop-nodemanager stop"
	pdsh -w ^rm_host "service hadoop-resourcemanager stop"

}

start_hadoop()
{

	pdsh -w ^nn_host "service hadoop-namenode start"
	pdsh -w ^snn_host "service hadoop-secondarynamenode start"
	pdsh -w ^dn_hosts "service hadoop-datanode start"
	pdsh -w ^rm_host "service hadoop-resourcemanager start"
	pdsh -w ^nm_hosts "service hadoop-nodemanager start"
	pdsh -w ^yarn_proxy_host "service hadoop-proxyserver start"
	pdsh -w ^mr_history_host "service hadoop-historyserver start"
}
