	groupadd hadoop
	useradd   yarn -s /bin/bash -b /user 
	passwd -d yarn
	useradd   hdfs -s /bin/bash -b /user 
	passwd -d hdfs
	useradd   mapred -s /bin/bash -b /user
	passwd -d mapred
	adduser yarn hadoop
	adduser hdfs hadoop
	adduser mapred hadoop
	make -C /var/yp
	make group -C /var/yp
	sleep 15
	pdsh -w ^all_hosts "mkdir /user/yarn; chown yarn /user/yarn; chgrp hadoop /user/yarn"
	pdsh -w ^all_hosts "mkdir /user/hdfs; chown hdfs /user/hdfs; chgrp hadoop /user/hdfs"
	pdsh -w ^all_hosts "mkdir /user/mapred; chown mapred /user/mapred; chgrp hadoop /user/mapred"